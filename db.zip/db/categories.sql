create table categories
(
    Id          int identity
        constraint PK_categories
            primary key,
    Name        nvarchar(255)                                   not null collate Latin1_General_CI_AI,
    Description nvarchar(2000),
    is_active   bit       default CONVERT([bit], 0)             not null,
    created_at  datetime2 default '0001-01-01T00:00:00.0000000' not null,
    deleted_at  datetime2,
    modified_at datetime2,
    ParentId    int
        constraint FK_categories_categories_ParentId
            references categories
)
go

create index IX_categories_Name
    on categories (Name)
go

create index IX_categories_ParentId
    on categories (ParentId)
go

INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'Sữa cho bé', N'23', 1, N'2024-06-19 10:57:32.0000000', null, N'2024-07-10 01:41:48.1795879', null);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'Sữa bột', null, 1, N'2024-06-19 10:58:15.0000000', null, N'2024-07-13 12:23:23.9942808', 1);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'0-12 Tháng', null, 1, N'2024-06-19 11:00:38.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'0-6 Tháng', null, 1, N'2024-06-19 11:01:19.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'6-12 Tháng', null, 1, N'2024-06-19 11:02:23.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1-2 Tuổi', null, 1, N'2024-06-19 11:02:55.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1-3 Tuổi', null, 1, N'2024-06-19 11:03:43.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'2+ Tuổi', null, 1, N'2024-06-19 11:04:09.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1-10 Tuổi', null, 1, N'2024-06-19 11:04:23.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'Sữa nước', null, 1, N'2024-06-19 11:05:45.0000000', null, null, 1);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1+ Tuổi', null, 1, N'2024-06-19 11:06:38.0000000', null, null, 10);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'6+ Tháng', null, 1, N'2024-06-19 11:07:00.0000000', null, null, 10);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'10+ Tuổi', null, 1, N'2024-06-19 11:07:41.0000000', null, null, 10);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'Sữa cho mẹ bầu và sau sinh', null, 1, N'2024-06-19 11:08:28.0000000', null, null, null);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'Sữa cho mẹ bầu', null, 1, N'2024-06-19 11:08:49.0000000', null, null, 14);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'3+ Tuổi', null, 1, N'2024-06-19 11:26:44.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1-10 Tuổi', null, 1, N'2024-06-19 12:24:46.0000000', null, null, 10);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1-3 Tuổi', N'', 1, N'2024-06-19 05:26:53.9342807', null, null, 10);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'2-6 Tuổi', null, 1, N'2024-06-22 18:05:37.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1+ Tuổi', null, 1, N'2024-06-22 18:08:37.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'6-24 Tháng', null, 1, N'2024-06-24 10:56:24.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'6+ Tuổi', null, 1, N'2024-06-29 09:53:24.0000000', null, null, 10);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'6-36 Tháng', null, 1, N'2024-06-29 10:17:27.0000000', null, null, 2);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'Sữa tươi', null, 1, N'2024-06-25 17:23:29.0000000', null, null, 1);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1-10 Tuổi', null, 1, N'2024-06-27 10:35:00.0000000', N'2024-07-24 09:17:34.4307674', N'2024-07-24 09:17:34.4794523', 26);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'1+ Tuổi', null, 1, N'2024-06-27 10:35:09.0000000', null, null, 26);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'Test', N'1213', 0, N'2024-07-09 01:50:58.6058050', N'2024-07-22 20:04:30.7367220', N'2024-07-22 13:04:30.8101510', null);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'213123', N'asd', 0, N'2024-07-09 01:51:59.2813330', N'2024-07-22 20:04:16.0255790', N'2024-07-22 13:04:16.1312490', null);
INSERT INTO yumilk.dbo.categories (name, description, is_active, created_at, deleted_at, modified_at, parent_id) VALUES (N'3-6 tuổi', N'Sữa bột dành cho trẻ em từ 3 đến 6 tuổi', 1, N'2024-07-23 04:35:46.6861244', null, null, 2);
